package main
 
import "xren/snipperbox/pkg/models"

 
// Добавляем поле Snippets в структуру templateData
type templateData struct {
    Snippet  *models.Snippet
    Snippets []*models.Snippet
}
