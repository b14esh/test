// Запускать 
// go run ./cmd/web

// error fix
// go: go.mod file not found in current directory or any parent directory; see 'go help modules'  
// go mod init main


// <название>.<роль>.tmpl


// страницы
// ui/html/home.page.tmpl - главная страница
// ui/html/base.layout.tmpl - отображаем на каждой странице
