// Запускать 
// go run ./cmd/web

// error fix
// go: go.mod file not found in current directory or any parent directory; see 'go help modules'  
// go mod init main


// <название>.<роль>.tmpl


// страницы
// ui/html/home.page.tmpl - главная страница
// ui/html/base.layout.tmpl - отображаем на каждой странице


// методы
Метод	URL      	     Обработчик  	    Действие
ANY  	/	             home      	        Отображение домашней страницы
ANY	    /                snippet?id=1	    showSnippet	Отображение определенной заметки
POST	/snippet/create	 createSnippet	    Создание новой заметки
ANY	    /static/	     http.FileServer	Обслуживание определенного статического файла
