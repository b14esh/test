// Запускать 
// go run ./cmd/web
// go run ./cmd/web -addr="127.0.0.1:9999"
// go run ./cmd/web -help
// go run ./cmd/web >>/tmp/info.log 2>>/tmp/error.log


// error fix
// go: go.mod file not found in current directory or any parent directory; see 'go help modules'  
// go mod init main


// <название>.<роль>.tmpl


// страницы
// ui/html/home.page.tmpl - главная страница
// ui/html/base.layout.tmpl - отображаем на каждой странице


// методы
Метод	URL      	     Обработчик  	    Действие
ANY  	/	             home      	        Отображение домашней страницы
ANY	    /                snippet?id=1	    showSnippet	Отображение определенной заметки
POST	/snippet/create	 createSnippet	    Создание новой заметки
ANY	    /static/	     http.FileServer	Обслуживание определенного статического файла



// cur test
проверка скачивания
curl -i -H "Range: bytes=100-199" --output - http://localhost:4000/static/img/logo.png
проверка запроса POST
curl -i -X POST http://127.0.0.1:4000/snippet/create
проверка запроса PUT
curl -i -X PUT http://127.0.0.1:4000/snippet/create
проверка запроса GET можно просто открыть страницу в браузере или 
curl -i -X GET http://127.0.0.1:4000/snippet/create


// собрать бинарник
// под x86
go build ./cmd/web
GOOS=windows GOARCH=386 go build ./cmd/web
GOOS=windows GOARCH=amd64 go build ./cmd/web
// под arm
GOOS=linux GOARCH=arm go build ./cmd/web
GOOS=darwin GOARCH=arm64 go build ./cmd/web



