// Запускать 
// go run ./cmd/web

// error fix
// go: go.mod file not found in current directory or any parent directory; see 'go help modules'  
// go mod init main
